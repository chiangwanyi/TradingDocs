---
name: zpa-interactive-report
description: 把一份盘面数据做成「图表在左、分析在右」的单文件交互式 HTML 分析报告——左侧常驻 K 线图（阶段聚焦、图层开关、悬停 OHLC、关键位锁定、情景叠加），右侧滚动展示分析六步、情景推演、关键位清单、背景证据与脚本现算事实，全部点击联动。用于把 zpa.market.v1 JSON（或已由 zpa-trading-analysis 得出的结论）转成可交付、可分享、可离线打开的可视化报告。触发词：盘面分析报告、交互报告、可视化报告、把盘面做成报告、K 线报告、HTML 报告、图表加结论、这份盘面做成交互页面、report.html、Zpa 报告。
agent_created: true
---

# Zpa 交互式分析报告

## 用途

把「**盘面数据 → 体系分析 → 可视化报告**」这条链路固定下来，避免每次重写一遍图表代码：

| 层 | 谁来做 | 产物 |
|---|---|---|
| ① 事实层 | 脚本 `scripts/market_facts.py` | `facts.json`（OHLC / EMA20 / ATR14 / 缺口 / 波段点 / 阶段腿 / 区间 / 关键位候选） |
| ② 结论层 | **加载 `zpa-trading-analysis` 技能后由体系判断填写** | `analysis.json`（六步 / 关键位 / 情景 / 证据 / 阶段划分 / 结论） |
| ③ 渲染层 | 脚本 `scripts/render_report.py` + `assets/page.template.html` | 单文件 HTML（零外部依赖，双击离线可开） |

**核心纪律**：报告里每一个数字都必须在 `facts.json` 里有出处，或由体系明确推导。`analysis.json` 只放判断，不放可以算出来的东西。

## 何时使用

- 用户给出一份盘面数据（zpa.market.v1 JSON）并要求「做成交互报告 / 可视化 / HTML 报告」。
- 已经用 `zpa-trading-analysis` 做完分析，想把结论落到一张可交互的图上报给用户。
- 需要一份能直接分享（单文件、无 CDN 依赖）、刷新或深链接能复原视图的报告。

若用户只要**文字结论**（不要求报告页），直接用 `zpa-trading-analysis` 技能即可，不要套这一层。

## 工作流

### 第 0 步 · 确认输入

要求输入是 **zpa.market.v1** 载荷（`meta` + `time` + `bars`）。若用户只给了 K 线截图，先按 `zpa-trading-analysis` 的流程把截图还原成 JSON 再进入本流程。

### 第 1 步 · 生成事实层

```bash
python <skill>/scripts/market_facts.py <market.json> -o <work>/<name>.facts.json --pretty
```

输出末尾会打印摘要（缺口数、ATR、三段区间、波段点/候选数）。**先读一遍 facts.json 再用**，尤其是：

- `notes` —— 脚本主动抛出的「数据本身的毛病」（零价格缺口、1 tick 噪声、未回补缺口、末根未收盘）。这些必须被显式考虑，不要静默忽略。
- `levelCandidates` —— 波段点按 `0.75×ATR` 聚出的关键位候选；`n` 就是「理由数」，`reasons` 是每个点的出处与时间。`side` 按「位于现价上方＝阻力 / 下方＝支撑」判定（前高被上破后即转为支撑）。
- `ranges.win / ranges.leg / ranges.ttr` —— 三段区间（窗口极值 / 主区间 / 当前窄幅区间）及其高度与根数。
- `afterLow` —— 低点之后的全部波段高点（含 `bars` 与 `retracePct`）。**机械切法只取最高那个，体系复盘常取更早的顶**，所以要复核。
- `mark.bearBar` —— 最大实体阴线，即「大阴线开盘价＝强阻力」的基准。

### 第 2 步 · 生成结论层

**先加载 `zpa-trading-analysis` 技能**（`Skill` 工具），按其 `references/01..07` 走「背景 → 缺口 → 支撑阻力 → Setup → 风控 → 自检」，再按本技能 `references/analysis.schema.md` 的契约写 `analysis.json`。

填写要点：

- `conclusion` —— 二元决策结论（趋势 / 震荡）＋置信度＋当下立场。
- `phases` —— 阶段划分。用 `facts.phaseHint` 当起点，但**必须按体系复核**（例如反弹顶取 12:10 还是 13:40，会直接改变「耗时几根」这条证据）。
- `levels` —— 从 `levelCandidates` 里挑并命名，`reasons` 直接引用候选里的出处。**理由数决定权重**，不要给只有单一理由的位标注「最强」。
- `steps` / `evidence` —— 六步结论与证据核对表；`points` 里可用 `**粗体**`，渲染时会转成高亮。
- `scenarios` —— 入场 / 止损 / 目标，**只写价格，RR 与风险点数由脚本算**，避免手算错。
- `range` —— 当前窄幅区间的上下沿，驱动测量位；`leg` 是 AB=CD 投影用的主区间高度。

### 第 3 步 · 渲染

```bash
python <skill>/scripts/render_report.py --facts <name>.facts.json --analysis <name>.analysis.json -o <out>.html
```

脚本会先做结构校验（索引越界、`focus` 引用不存在的位 id、`side` 取值、`targets` 缺字段），有问题打 `[!]` 警告但继续渲染 —— **警告要逐条修掉再交付**。

不传 `--analysis` 可渲染「纯事实视图」，便于先单独检查图表本身。

### 第 4 步 · 自检并交付

用无头浏览器截图核对排版（关键位标签互压、情景标签叠字、阶段注释被遮），确认无误后用 `present_files` 打开报告。

```bash
"<edge|chrome>" --headless=new --disable-gpu --hide-scrollbars \
  --virtual-time-budget=3000 --window-size=1600,1000 \
  --screenshot=<shot>.png "file:///<abs-path>/<out>.html"
```

若本机没有浏览器，至少要检查「外部依赖为空」与「占位符无残留」：

```bash
grep -oE '(src|href)="[^"]*"' <out>.html | sort -u   # 只应出现 data: 协议
grep -c '__PAGE_TITLE__' <out>.html                  # 必须为 0
```

## 页面结构与交互

```
header（标题 + 结论 / 现价） · metrics（8 张指标卡）
┌──────────── 左（sticky，跟随滚动） ────────────┬────── 右（滚动） ──────┐
│ 控制条：阶段聚焦 chip / 图层开关               │ 分析六步               │
│ 图表：原生 SVG K 线 + 阶段分区 + 关键位 +      │ 情景推演               │
│       测量目标 + 情景叠加                      │ 关键位清单             │
│                                                │ 背景判断证据           │
│                                                │ 行情事实 · 脚本现算    │
└────────────────────────────────────────────────┴────────────────────────┘
缺口清单（全宽，可筛选）
```

| 交互 | 效果 |
|---|---|
| 阶段聚焦 chip | 非当前阶段的 K 线整体压暗到 18%，当前阶段高亮并显示时间 / 幅度注释 |
| 图层开关 | 阶段分区 / 缺口与大阴线 / 支撑阻力 / 测量目标 / EMA20 逐层开关 |
| 悬停 K 线 | 十字线 + 浮层显示开高低收、幅度、区间高度 |
| 点「分析六步」卡 | 图上只保留该步相关关键位，其余淡出 |
| 悬停 / 点击关键位 | 悬停预览加粗，点击锁定并展开该位全部理由 |
| 点情景 A / B / C | 叠加风险区（红）/ 收益区（绿）、入场止损目标线、方向箭头与 RR |
| 缺口表筛选 | 全部 / 仅未回补 / 仅非噪声 / 仅价格缺口 |
| 深链接 | `#sc=A&ph=4&lv=r1` 可分享并复原视图 |

布局约束：左栏 470px 固定、图表视图 `viewBox="0 0 1000 460"`；窗口窄于 1280px 或矮于 700px 时自动放弃 sticky，改为上下堆叠。

## 文件

```
zpa-interactive-report/
├── SKILL.md
├── scripts/
│   ├── market_facts.py      # zpa.market.v1 -> facts.json（纯客观事实，无判断）
│   └── render_report.py     # facts + analysis -> 单文件 HTML（含结构校验）
├── assets/
│   └── page.template.html   # 页面骨架 + 原生 SVG 图表 + 原生 JS
│                            #   占位符：__PAGE_TITLE__ 与 /*__DATA__*/
└── references/
    └── analysis.schema.md   # analysis.json 字段契约与填写规则
```

## 常见错误

| 现象 | 原因 |
|---|---|
| 缺口数量远大于 CLI 摘要 | 缺口口径写错。实体缺口必须用**实体与实体不重叠**（不是「开盘≠昨收」），价格缺口要求**引线与引线不重叠**；宽度 < `tickSize` 的忽略 |
| 时间比行情图差 8 小时 | 把时间当 UTC 处理。要按源数据自带的 UTC 偏移显示（`time.start` 里的 `+08:00`） |
| 窄幅区间的「根数」对不上 | 用的是机械切法（全窗口最高点）而不是体系口径。在 `analysis.phases` 里显式给出 `from_idx` / `to_idx` |
| 关键位标签互相压住 | 图表右侧留白 `PAD.r` 不足，或两位价差过小。应合并成一个「带」而不是叠两条线 |
| 情景入场 / 止损只差几个点，标签叠字 | 模板已按「入场在止损上方 / 下方」分列两侧；仍重叠时应缩短文案或加大 `PAD` |

## 不做的事

- 不替体系下结论：`facts.json` 里没有任何「趋势 / 震荡」判断，结论必须来自 `zpa-trading-analysis`。
- 不引入外部依赖：页面必须单文件可离线打开，不加 CDN、不引图表库。
- 不把推导结果写回 `facts.json`：能算就在渲染层算。
