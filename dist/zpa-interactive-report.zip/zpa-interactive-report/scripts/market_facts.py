#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""zpa.market.v1 JSON -> facts.json：只输出**客观可计算事实**，不含任何体系结论。

把「能从数据算出来的」和「必须靠体系判断的」彻底分开：
  · 本脚本负责前者（bars / EMA / ATR / 缺口 / 波段点 / 阶段 / 区间 / 测量位 / 关键位候选）
  · 后者写进 analysis.json，由 agent 加载 zpa-trading-analysis 体系后填写
  · render_report.py 把两者合并成单文件 HTML

用法:
    python market_facts.py <market.json> [-o facts.json]

依赖: 纯标准库。
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime

# 缺口口径与 zpa-trading-analysis/scripts/market_digest.py 保持一致，保证可对账
EPS = 1e-9
NOISE_RATIO = 1.0  # 宽度 < 1 个「真实 tick」视为量化噪声（tick 由 meta.price.tickSize 推得）


# ---------------------------------------------------------------- 读取

def _fmt_time(t: str) -> tuple[str, str, str]:
    """rfc3339 / epoch 一律转成本地偏移下的 HH:MM、MM-DD HH:MM、YYYY-MM-DD。"""
    s = str(t).strip().replace("Z", "+00:00")
    dt = datetime.fromisoformat(s)
    return dt.strftime("%H:%M"), dt.strftime("%m-%d %H:%M"), dt.strftime("%Y-%m-%d")


def load_market(path: str) -> dict:
    with open(path, encoding="utf-8") as f:
        payload = json.load(f)
    for k in ("meta", "time", "bars"):
        if k not in payload:
            raise SystemExit(f"[x] 载荷缺少 {k}（应为 zpa.market.v1）")
    bars_obj = payload["bars"]
    layout = bars_obj.get("layout", "rows")
    if layout == "rows":
        raw = bars_obj["rows"]
    elif layout == "columns":
        cols = bars_obj["columns"]
        n = len(cols["t"])
        raw = [{k: cols[k][i] for k in ("t", "o", "h", "l", "c")} for i in range(n)]
    else:
        raise SystemExit(f"[x] bars.layout 非法: {layout!r}")

    bars = []
    for r in raw:
        hhmm, stamp, day = _fmt_time(r["t"])
        bars.append({
            "i": len(bars), "t": hhmm, "ts": stamp, "d": day, "iso": str(r["t"]),
            "o": float(r["o"]), "h": float(r["h"]), "l": float(r["l"]), "c": float(r["c"]),
            "closed": bool(r.get("closed", True)),
        })
    if len(bars) < 10:
        raise SystemExit(f"[x] K 线过少（{len(bars)} 根），无法分析")
    return {"meta": payload["meta"], "time": payload["time"], "bars": bars}


# ---------------------------------------------------------------- 指标

def ema(values: list[float], period: int = 20) -> list[float | None]:
    out: list[float | None] = [None] * len(values)
    if len(values) < period:
        return out
    k = 2.0 / (period + 1)
    prev = sum(values[:period]) / period
    out[period - 1] = prev
    for i in range(period, len(values)):
        prev = values[i] * k + prev * (1 - k)
        out[i] = prev
    return out


def true_ranges(bars: list[dict]) -> list[float]:
    out = []
    for i in range(1, len(bars)):
        a, b = bars[i - 1], bars[i]
        out.append(max(b["h"] - b["l"], abs(b["h"] - a["c"]), abs(b["l"] - a["c"])))
    return out


def atr(bars: list[dict], period: int = 14) -> float:
    trs = true_ranges(bars)
    if not trs:
        return 0.0
    return sum(trs[-period:]) / min(period, len(trs))


# ---------------------------------------------------------------- 缺口

def detect_gaps(bars: list[dict], tick: float, noise: float) -> list[dict]:
    """口径同 zpa-trading-analysis 的 market_digest.detect_gaps。

    · 价格缺口：前一根的 高/低 与当前根的 高/低 不重叠（引线级）
    · 实体缺口：前一根实体 与 当前根实体 不重叠（「开盘≠昨收」不算缺口）
    · 宽度 < tick 的忽略；< noise 的标记为量化噪声
    """
    out: list[dict] = []
    for i in range(1, len(bars)):
        p, cur = bars[i - 1], bars[i]
        checks = [
            ("price", "up", p["h"], cur["l"], p["h"] < cur["l"] - EPS),
            ("price", "down", cur["h"], p["l"], cur["h"] < p["l"] - EPS),
            ("body", "up", max(p["o"], p["c"]), min(cur["o"], cur["c"]),
             max(p["o"], p["c"]) < min(cur["o"], cur["c"]) - EPS),
            ("body", "down", max(cur["o"], cur["c"]), min(p["o"], p["c"]),
             max(cur["o"], cur["c"]) < min(p["o"], p["c"]) - EPS),
        ]
        for kind, direction, lower, upper, hit in checks:
            if not hit or (tick and (upper - lower) < tick - EPS):
                continue
            fill_idx = None
            for j in range(i + 1, len(bars)):
                if direction == "up" and bars[j]["l"] <= lower + EPS:
                    fill_idx = j
                    break
                if direction == "down" and bars[j]["h"] >= upper - EPS:
                    fill_idx = j
                    break
            out.append({
                "i": i, "t": bars[i]["t"], "ts": bars[i]["ts"], "kind": kind, "dir": direction,
                "lo": round(lower, 2), "hi": round(upper, 2), "size": round(upper - lower, 2),
                "noise": (upper - lower) < noise,
                "filled": fill_idx is not None,
                "fillT": bars[fill_idx]["t"] if fill_idx is not None else None,
                "fillIn": (fill_idx - i) if fill_idx is not None else None,
            })
    return out


# ---------------------------------------------------------------- 波段

def swings(bars: list[dict], k: int = 2) -> list[dict]:
    """k 根左右都更极端的点，视为波段高/低点（无未来函数：只用到 i±k）。"""
    out = []
    for i in range(k, len(bars) - k):
        win = [bars[j] for j in range(i - k, i + k + 1) if j != i]
        if all(bars[i]["h"] > w["h"] for w in win):
            out.append({"i": i, "type": "H", "price": round(bars[i]["h"], 2), "t": bars[i]["t"], "ts": bars[i]["ts"]})
        if all(bars[i]["l"] < w["l"] for w in win):
            out.append({"i": i, "type": "L", "price": round(bars[i]["l"], 2), "t": bars[i]["t"], "ts": bars[i]["ts"]})
    return out


def cluster_levels(points: list[dict], tol: float) -> list[dict]:
    """把价位相近的波段点聚成一档，簇内点数＝该位的「理由数」。"""
    pts = sorted(points, key=lambda p: p["price"])
    groups: list[list[dict]] = []
    cur: list[dict] = []
    for p in pts:
        if cur and abs(p["price"] - sum(x["price"] for x in cur) / len(cur)) > tol:
            groups.append(cur)
            cur = []
        cur.append(p)
    if cur:
        groups.append(cur)
    out = []
    for grp in groups:
        out.append({
            "price": round(sum(x["price"] for x in grp) / len(grp), 2),
            "lo": round(min(x["price"] for x in grp), 2),
            "hi": round(max(x["price"] for x in grp), 2),
            "n": len(grp),
            "points": [{"price": x["price"], "t": x["t"], "type": x["type"], "i": x["i"]} for x in grp],
        })
    return out


# ---------------------------------------------------------------- 主流程

def build_facts(market: dict) -> dict:
    meta, tm, bars = market["meta"], market["time"], market["bars"]
    n = len(bars)
    closes = [b["c"] for b in bars]
    highs = [b["h"] for b in bars]
    lows = [b["l"] for b in bars]

    tick = float((meta.get("price") or {}).get("tickSize", 0) or 0)
    # 截图还原的数据：tickSize 常写成 0.01，但标的真实最小变动可能是 0.25。
    # 噪声阈值取「数据的报价精度」与「真实 tick」的较大者，避免把 1 个真实 tick 当有效缺口。
    true_tick = 0.25 if meta.get("symbol", "").startswith("MNQ") else 0.0
    noise_tol = true_tick * NOISE_RATIO if true_tick else max(tick * 3, 0.3)

    e = ema(closes)
    a14 = atr(bars)
    gaps = detect_gaps(bars, tick, noise_tol)

    hi_i = highs.index(max(highs))
    lo_i = lows.index(min(lows))

    # ---- 阶段建议：按「最高 → 之后最低 → 之后最高 → 尾」四条腿切 ----
    after_lo = highs[lo_i:]
    reb_i = lo_i + after_lo.index(max(after_lo)) if lo_i < n - 1 else lo_i
    legs = []
    if hi_i > 0:
        legs.append({"tag": "up", "from_idx": 0, "to_idx": hi_i})
    if lo_i > hi_i:
        legs.append({"tag": "down", "from_idx": hi_i, "to_idx": lo_i})
    if reb_i > lo_i:
        legs.append({"tag": "rebound", "from_idx": lo_i, "to_idx": reb_i})
    if reb_i < n - 1:
        legs.append({"tag": "ttr", "from_idx": reb_i, "to_idx": n - 1})

    seg = {x["tag"]: x for x in legs}
    up = seg.get("up")
    dn = seg.get("down")
    rb = seg.get("rebound")
    tt = seg.get("ttr")

    sw = swings(bars, 2)

    # 三段区间：窗口极值 / 主区间（当日最低 → 反弹最高）/ 当前窄幅区间
    win = {"lo": round(min(lows), 2), "hi": round(max(highs), 2), "loIdx": lo_i, "hiIdx": hi_i,
           "loT": bars[lo_i]["ts"], "hiT": bars[hi_i]["ts"]}
    win["height"] = round(win["hi"] - win["lo"], 2)

    leg = {"lo": win["lo"], "hi": round(bars[reb_i]["h"], 2), "loIdx": lo_i, "hiIdx": reb_i,
           "loT": bars[lo_i]["ts"], "hiT": bars[reb_i]["ts"]}
    leg["height"] = round(leg["hi"] - leg["lo"], 2)

    if tt:
        sz = slice(tt["from_idx"], tt["to_idx"] + 1)
        t_lo, t_hi = min(lows[sz]), max(highs[sz])
        t_lo_i = tt["from_idx"] + lows[sz].index(t_lo)
        t_hi_i = tt["from_idx"] + highs[sz].index(t_hi)
        ttr = {"lo": round(t_lo, 2), "hi": round(t_hi, 2), "loIdx": t_lo_i, "hiIdx": t_hi_i,
               "loT": bars[t_lo_i]["ts"], "hiT": bars[t_hi_i]["ts"],
               "from_idx": tt["from_idx"], "to_idx": tt["to_idx"],
               "bars": tt["to_idx"] - tt["from_idx"] + 1}
        ttr["height"] = round(ttr["hi"] - ttr["lo"], 2)
    else:
        ttr = None

    # 低点之后的波段高点（反弹段候选顶）——机械切法取「最高那个」，但复盘常取更早的那个顶，
    # 因此把候选全部列出，由体系分析决定用哪个。
    after_low = []
    for p in sw:
        if p["type"] != "H" or p["i"] <= lo_i:
            continue
        after_low.append({
            "i": p["i"], "t": p["t"], "price": p["price"], "bars": p["i"] - lo_i,
            "retracePct": round((p["price"] - win["lo"]) / win["height"] * 100, 1) if win["height"] else 0.0,
        })
    after_low.sort(key=lambda x: x["i"])

    # 关键位候选：波段点（高低分开）按 0.75×ATR 聚类
    tol = max(tick * 3, a14 * 0.75, 0.5)
    last = closes[-1]
    cand = []
    for origin, pts in (("H", [p for p in sw if p["type"] == "H"]),
                        ("L", [p for p in sw if p["type"] == "L"]),
                        ("X", [{"i": hi_i, "type": "H", "price": round(max(highs), 2), "t": bars[hi_i]["ts"], "ts": bars[hi_i]["ts"]},
                               {"i": lo_i, "type": "L", "price": round(min(lows), 2), "t": bars[lo_i]["ts"], "ts": bars[lo_i]["ts"]}])):
        for grp in cluster_levels(pts, tol):
            grp["origin"] = origin
            cand.append(grp)
    for grp in cand:
        # 体系里「阻力/支撑」由它相对当前价的位置决定（前高被上破后即转为支撑），而不是由它当初的高低点身份决定
        grp["side"] = "res" if grp["price"] > last else "sup"
        grp["dist"] = round(grp["price"] - last, 2)
        grp["reasons"] = ["{} {:.2f}（{}）".format("极值" if grp["origin"] == "X" else ("前高" if x["type"] == "H" else "前低"),
                                                  x["price"], x["t"]) for x in grp["points"]]
    cand.sort(key=lambda d: (d["n"], -abs(d["dist"])), reverse=True)

    # 大实体阴线（体系里「大阴线开盘价＝强阻力」的基准）
    bears = [b for b in bars if b["c"] < b["o"]]
    bear = max(bears, key=lambda b: b["o"] - b["c"]) if bears else None

    unfilled = [g for g in gaps if not g["filled"]]
    filled = [g for g in gaps if g["filled"]]

    # ---- 事实级提醒（写进 notes，供分析时显式考虑，别静默忽略）----
    notes = []
    if not any(g["kind"] == "price" for g in gaps):
        notes.append("全窗口 0 个价格（引线）缺口 —— 缺口工具在结构层面失效。")
    noisy = [g for g in gaps if g["noise"]]
    if noisy:
        notes.append(f"{len(noisy)} 个缺口的宽度 ≈ 1 个真实 tick（{noise_tol} 点），属截图还原的量化噪声，不可当突破型缺口使用。")
    if unfilled:
        notes.append("存在未回补缺口：" + "；".join(f"{g['lo']}–{g['hi']}（{g['kind']}，宽 {g['size']}）" for g in unfilled))
    if not bars[-1]["closed"]:
        notes.append("末根 K 线未收盘（closed=false），其高低点可能继续移动，不可作为最终摆动点。")
    if rb and win["height"]:
        rise = round(bars[reb_i]["h"] - win["lo"], 2)
        notes.append(f"反弹腿 {rise} 点 / {reb_i - lo_i} 根，回撤空头腿 {round(rise / win['height'] * 100, 1)}%"
                     "（机械切法用全窗口最高点，体系复盘可取更早的候选顶，见 afterLow）。")

    stats = {
        "n": n,
        "open": round(bars[0]["o"], 2), "close": round(bars[-1]["c"], 2),
        "high": round(max(highs), 2), "highT": bars[hi_i]["ts"], "highIdx": hi_i,
        "low": round(min(lows), 2), "lowT": bars[lo_i]["ts"], "lowIdx": lo_i,
        "change": round(bars[-1]["c"] - bars[0]["o"], 2),
        "changePct": round((bars[-1]["c"] / bars[0]["o"] - 1) * 100, 2),
        "openT": bars[0]["ts"], "closeT": bars[-1]["ts"],
        "date": bars[0]["d"],
    }

    metrics = {}
    if dn and up:
        metrics["downLeg"] = {"points": round(bars[hi_i]["h"] - bars[lo_i]["l"], 2),
                              "bars": lo_i - hi_i}
    if rb:
        metrics["rebound"] = {
            "points": round(bars[reb_i]["h"] - bars[lo_i]["l"], 2),
            "bars": reb_i - lo_i,
            "retracePct": round((bars[reb_i]["h"] - bars[lo_i]["l"]) /
                                (bars[hi_i]["h"] - bars[lo_i]["l"]) * 100, 1)
            if bars[hi_i]["h"] > bars[lo_i]["l"] else 0.0,
        }
    if tt and ttr:
        metrics["ttr"] = {"bars": ttr["bars"], "height": ttr["height"]}

    # 机械四段切法：只作起点建议，最终阶段划分由体系分析在 analysis.json 里给定
    phase_hint = [
        {"id": 1, "label": "① 上行至最高", "from_idx": 0, "to_idx": hi_i, "bars": hi_i + 1},
        {"id": 2, "label": "② 空头腿", "from_idx": hi_i, "to_idx": lo_i, "bars": lo_i - hi_i + 1},
        {"id": 3, "label": "③ 反弹", "from_idx": lo_i, "to_idx": reb_i, "bars": reb_i - lo_i + 1},
        {"id": 4, "label": "④ 窄幅震荡", "from_idx": reb_i, "to_idx": n - 1, "bars": n - reb_i},
    ]

    return {
        "schema": "zpa.report.facts.v1",
        "meta": {
            "symbol": meta.get("symbol"), "name": meta.get("name"), "interval": meta.get("interval"),
            "venue": meta.get("venue"), "assetClass": meta.get("assetClass"),
            "currency": meta.get("currency"), "source": meta.get("source"),
            "decimals": (meta.get("price") or {}).get("decimals", 2),
            "tickSize": tick, "noiseTol": noise_tol,
            "timezone": tm.get("timezone"), "timeFormat": tm.get("format"),
            "start": tm.get("start"), "end": tm.get("end"), "generatedAt": tm.get("generatedAt"),
        },
        "bars": bars,
        "ema": [None if v is None else round(v, 2) for v in e],
        "atr": round(a14, 2),
        "stats": stats,
        "gaps": {
            "total": len(gaps), "filled": len(filled), "unfilled": unfilled,
            "noise": len(noisy), "nPrice": len([g for g in gaps if g["kind"] == "price"]),
            "nBody": len([g for g in gaps if g["kind"] == "body"]),
            "tick": tick, "items": sorted(gaps, key=lambda g: -g["size"]),
        },
        "swings": sw,
        "afterLow": after_low,
        "levelCandidates": cand,
        "legs": legs,
        "phaseHint": phase_hint,
        "ranges": {"win": win, "leg": leg, "ttr": ttr},
        "mark": {"bearBar": ({"i": bear["i"], "t": bear["ts"], "o": bear["o"], "h": bear["h"],
                              "l": bear["l"], "c": bear["c"], "range": round(bear["o"] - bear["c"], 2)}
                             if bear else None)},
        "metrics": metrics,
        "notes": [x for x in notes if x],
    }


def main() -> None:
    ap = argparse.ArgumentParser(description="zpa.market.v1 -> facts.json（纯客观事实）")
    ap.add_argument("market")
    ap.add_argument("-o", "--out", default=None)
    ap.add_argument("--pretty", action="store_true")
    args = ap.parse_args()

    facts = build_facts(load_market(args.market))
    out = args.out or os.path.splitext(args.market)[0] + ".facts.json"
    with open(out, "w", encoding="utf-8") as f:
        json.dump(facts, f, ensure_ascii=False, indent=2 if args.pretty else None,
                  separators=None if args.pretty else (",", ":"))

    g = facts["gaps"]
    r = facts["ranges"]
    print(f"[ok] {out}")
    print(f"     {facts['meta']['symbol']} {facts['meta']['interval']} · {facts['stats']['n']} 根 · "
          f"{facts['stats']['openT']} → {facts['stats']['closeT']}")
    print(f"     缺口 {g['total']}（价格 {g['nPrice']} / 实体 {g['nBody']}）· 未回补 {len(g['unfilled'])} · 噪声 {g['noise']}")
    print(f"     ATR14 {facts['atr']} · 窗口 {r['win']['lo']}–{r['win']['hi']}（高 {r['win']['height']}）"
          f" · 主区间 {r['leg']['lo']}–{r['leg']['hi']}（高 {r['leg']['height']}）"
          + (f" · 窄幅 {r['ttr']['lo']}–{r['ttr']['hi']}（高 {r['ttr']['height']}，{r['ttr']['bars']} 根）" if r["ttr"] else ""))
    print(f"     波段点 {len(facts['swings'])} · 关键位候选 {len(facts['levelCandidates'])} · 反弹候选顶 {len(facts['afterLow'])}")


if __name__ == "__main__":
    sys.exit(main())
