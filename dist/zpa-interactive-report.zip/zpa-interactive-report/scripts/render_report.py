#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把 facts.json（脚本现算事实）+ analysis.json（体系结论）合并成单文件交互式 HTML 报告。

用法:
    python render_report.py --facts facts.json --analysis analysis.json -o report.html
    python render_report.py --facts facts.json -o facts-only.html      # 无结论时只出「事实视图」

设计要点:
  · 页面里所有数字（OHLC / 缺口 / EMA / ATR / 测量位 / 盈亏比）全部由脚本现算，不做手工录入
  · 结论段落（六步 / 情景 / 关键位 / 证据）来自 analysis.json，由体系分析填写
  · 输出零外部依赖：单文件、可离线双击打开

依赖: 纯标准库。
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE = os.path.join(os.path.dirname(HERE), "assets", "page.template.html")

TONE_OK = {"ok", "good", "fine"}


# ---------------------------------------------------------------- 工具

def die(msg: str) -> None:
    raise SystemExit(f"[x] {msg}")


def rnd(x, d: int = 2) -> float:
    return round(float(x) + 0.0, d)


def rr(entry: float, stop: float, target: float) -> float:
    risk = abs(entry - stop)
    return round(abs(target - entry) / risk, 2) if risk else 0.0


def load_json(path: str) -> dict:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


# ---------------------------------------------------------------- 合并

def build_measure(facts: dict, analysis: dict) -> list[dict]:
    """测量位：优先用 analysis.mm；否则由 analysis.range / facts 区间现算。"""
    if analysis.get("mm"):
        return analysis["mm"]
    r = facts.get("ranges") or {}
    rng = analysis.get("range") or {}
    ttr = r.get("ttr") or r.get("leg") or r.get("win")
    if not ttr:
        return []
    lo = float(rng.get("lo", ttr["lo"]))
    hi = float(rng.get("hi", ttr["hi"]))
    h = rnd(hi - lo)
    leg = float(rng.get("leg") or (r.get("leg") or {}).get("height") or h)
    return [
        dict(id="m1", dir="up", price=rnd(hi + h), name="上破测量", why=f"区间高 {h} 自 {hi} 上投"),
        dict(id="m2", dir="up", price=rnd(lo + leg), name="引线 AB=CD", why=f"主区间 {leg} 自 {lo} 投影"),
        dict(id="m3", dir="down", price=rnd(lo - h), name="下破测量", why=f"区间高 {h} 自 {lo} 下投"),
    ]


def build_scenarios(analysis: dict) -> list[dict]:
    out = []
    for s in analysis.get("scenarios") or []:
        if not isinstance(s, dict) or s.get("entry") is None or s.get("stop") is None:
            print(f"[!] 跳过无法绘制的情景 {s.get('id') if isinstance(s, dict) else s!r}：缺 entry / stop")
            continue
        s = dict(s)
        s.setdefault("accent", "ok")
        s["entry"] = rnd(s["entry"])
        s["stop"] = rnd(s["stop"])
        s["risk"] = rnd(abs(s["entry"] - s["stop"]))
        tg = []
        for t in s.get("targets") or []:
            if not isinstance(t, dict) or t.get("p") is None:
                continue
            t = dict(t)
            t["p"] = rnd(t["p"])
            t.setdefault("label", "目标")
            t["rr"] = rr(s["entry"], s["stop"], t["p"])
            tg.append(t)
        if not tg:
            print(f"[!] 跳过情景 {s.get('id')}：没有任何可用目标位")
            continue
        s["targets"] = tg
        out.append(s)
    return out


def build_phases(facts: dict, analysis: dict) -> list[dict]:
    """阶段：优先用 analysis.phases；否则退化为顶层腿的机械切法。

    索引一律夹到 [0, n-1]，避免 analysis.json 写坏时整张图错位。
    """
    n = len(facts["bars"])
    bars = facts["bars"]
    ph = analysis.get("phases")
    out = []
    if ph:
        for h in ph:
            try:
                a = max(0, min(n - 1, int(h["from_idx"])))
                b = max(0, min(n - 1, int(h["to_idx"])))
            except (KeyError, TypeError, ValueError):
                print(f"[!] 跳过阶段 {h.get('label') if isinstance(h, dict) else h!r}：from_idx / to_idx 不可用")
                continue
            if b < a:
                a, b = b, a
            out.append(dict(id=h.get("id", len(out) + 1), label=h.get("label", ""),
                            time=h.get("time") or f"{bars[a]['t']}–{bars[b]['t']}",
                            from_idx=a, to_idx=b, note=h.get("note", "")))
        if out:
            return out
    for h in facts.get("phaseHint") or []:
        a, b = h["from_idx"], h["to_idx"]
        out.append(dict(id=h["id"], label=h["label"], time=f"{bars[a]['t']}–{bars[b]['t']}",
                        from_idx=a, to_idx=b, note=f"{h['bars']} 根"))
    return out


def build_levels(facts: dict, analysis: dict) -> list[dict]:
    """关键位：缺 side 时按「相对现价的位置」补，缺 price 的直接丢弃（画不出来）。"""
    last = float(facts["stats"]["close"])
    out = []
    for l in analysis.get("levels") or []:
        if not isinstance(l, dict) or l.get("price") is None:
            print(f"[!] 跳过无法绘制的关键位 {l.get('id') if isinstance(l, dict) else l!r}：缺 price")
            continue
        l = dict(l)
        l["price"] = rnd(l["price"])
        l["side"] = l.get("side") if l.get("side") in ("res", "sup") else ("res" if l["price"] > last else "sup")
        l.setdefault("id", f"lv{len(out) + 1}")
        l.setdefault("name", "")
        l.setdefault("reasons", [])
        out.append(l)
    return out


def validate(facts: dict, analysis: dict) -> list[str]:
    warn = []
    n = len(facts["bars"])
    ids = {l["id"] for l in analysis.get("levels") or []}
    for ph in analysis.get("phases") or []:
        for k in ("from_idx", "to_idx"):
            if not isinstance(ph.get(k), int) or not (0 <= ph[k] < n):
                warn.append(f"phases[{(ph.get('label'))!r}].{k}={ph.get(k)!r} 越界（0..{n - 1}）")
    for st in analysis.get("steps") or []:
        for f in st.get("focus") or []:
            if f not in ids:
                warn.append(f"steps[{st.get('n')}].focus 引用了不存在的关键位 id: {f!r}")
    for s in analysis.get("scenarios") or []:
        if s.get("dir") not in ("short", "long"):
            warn.append(f"scenarios[{s.get('id')}].dir 应为 short|long，得到 {s.get('dir')!r}")
        if not s.get("targets"):
            warn.append(f"scenarios[{s.get('id')}] 缺 targets")
        for t in s.get("targets") or []:
            if t.get("p") is None or not t.get("label"):
                warn.append(f"scenarios[{s.get('id')}] 的 target 需要 p 与 label")
    for l in analysis.get("levels") or []:
        if l.get("side") not in ("res", "sup"):
            warn.append(f"levels[{l.get('id')}].side 应为 res|sup，得到 {l.get('side')!r}")
        if not l.get("reasons"):
            warn.append(f"levels[{l.get('id')}] 没有 reasons —— 体系里「理由数」直接影响该位权重")
    return warn


# ---------------------------------------------------------------- 主流程

def main() -> None:
    ap = argparse.ArgumentParser(description="facts.json + analysis.json -> 单文件交互式 HTML 报告")
    ap.add_argument("--facts", required=True)
    ap.add_argument("--analysis", default=None)
    ap.add_argument("-o", "--out", default=None)
    ap.add_argument("--title", default=None)
    ap.add_argument("--template", default=None)
    args = ap.parse_args()

    facts = load_json(args.facts)
    if facts.get("schema") == "zpa.market.v1":
        die(f"--facts 收到的是盘面数据（zpa.market.v1），请先用 market_facts.py 转成 facts.json：\n"
            f"    python market_facts.py {args.facts} -o facts.json")
    if facts.get("schema") != "zpa.report.facts.v1":
        die(f"facts 载荷 schema 应为 zpa.report.facts.v1，得到 {facts.get('schema')!r}")
    analysis = load_json(args.analysis) if args.analysis else {}

    for w in validate(facts, analysis):
        print(f"[!] {w}")

    m = facts["meta"]
    st = facts["stats"]
    tpl_path = args.template or TEMPLATE
    if not os.path.exists(tpl_path):
        die(f"模板不存在: {tpl_path}")
    with open(tpl_path, encoding="utf-8") as f:
        html = f.read()

    bars = [{k: b[k] for k in ("t", "ts", "o", "h", "l", "c")} for b in facts["bars"]]
    bear = facts["mark"].get("bearBar")
    if bear:
        bear = dict(bear, t=bear["t"])

    mm = build_measure(facts, analysis)
    scen = build_scenarios(analysis)
    phases = build_phases(facts, analysis)
    levels = build_levels(facts, analysis)
    steps = []
    for i, it in enumerate(analysis.get("steps") or []):
        if not isinstance(it, dict):
            continue
        it = dict(it)
        it["n"] = it.get("n") or (i + 1)
        it["focus"] = list(it.get("focus") or [])
        it["points"] = it.get("points") or []
        it.setdefault("tone", "warn")
        steps.append(it)

    conclusion = analysis.get("conclusion") or {}
    r = facts.get("ranges") or {}
    rng_tpl = analysis.get("range") or {}
    ttr = r.get("ttr") or r.get("leg") or r.get("win") or {"lo": st["low"], "hi": st["high"]}
    rang = dict(lo=rnd(rng_tpl.get("lo", ttr["lo"])), hi=rnd(rng_tpl.get("hi", ttr["hi"])))
    rang["height"] = rnd(rang["hi"] - rang["lo"])

    symbol = m.get("symbol", "?")
    interval = m.get("interval", "?")
    date = st.get("date", "")
    title = args.title or analysis.get("title") or f"{symbol} {interval} · Z说交易体系盘面分析（{date}）"

    data = dict(
        title=title,
        meta=dict(symbol=symbol, name=m.get("name"), interval=interval, venue=m.get("venue"),
                  assetClass=m.get("assetClass"), currency=m.get("currency"), source=m.get("source"),
                  timezone=m.get("timezone"), tickSize=m.get("tickSize"), noiseTol=m.get("noiseTol"),
                  start=m.get("start"), end=m.get("end"), date=date),
        bars=bars,
        ema=facts["ema"],
        atr=facts["atr"],
        stats=dict(st, tz="CST"),
        ranges=r,
        metrics=facts.get("metrics") or {},
        notes=facts.get("notes") or [],
        levelCandidates=(facts.get("levelCandidates") or [])[:24],
        gaps=facts["gaps"],
        bearBar=bear,
        phases=phases,
        levels=levels,
        mm=mm,
        range=rang,
        scenarios=scen,
        steps=steps,
        evidence=[e for e in (analysis.get("evidence") or []) if isinstance(e, dict)],
        conclusion=dict(label=conclusion.get("label", "未给结论"),
                        conf=conclusion.get("conf", ""),
                        stance=conclusion.get("stance", ""),
                        price=rnd(conclusion.get("price", st["close"]))),
        source=dict(facts=os.path.basename(args.facts),
                    analysis=os.path.basename(args.analysis) if args.analysis else None,
                    generatedAt=datetime.now().strftime("%Y-%m-%d %H:%M")),
    )

    html = html.replace("__PAGE_TITLE__", title.replace("&", "&amp;").replace("<", "&lt;"))
    html = html.replace("/*__DATA__*/", json.dumps(data, ensure_ascii=False, separators=(",", ":")))

    out = args.out or os.path.splitext(args.facts)[0] + ".report.html"
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"[ok] {out}  ({len(html) / 1024:.0f} KB)")
    print(f"     {symbol} {interval} · {st['n']} 根 · 缺口 {facts['gaps']['total']} · "
          f"关键位 {len(levels)} · 情景 {len(scen)} · 六步 {len(steps)} · 阶段 {len(phases)}")


if __name__ == "__main__":
    sys.exit(main())
