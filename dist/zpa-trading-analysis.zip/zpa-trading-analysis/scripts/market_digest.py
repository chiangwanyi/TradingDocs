#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
market_digest.py — zpa.market.v1 数据校验 + 盘面结构摘要

用法:
    python market_digest.py <market.json> [--last 40] [--swing-k 2] [--json]

输入契约 (zpa.market.v1):
    { "schema", "meta", "time", "bars": { "count", "layout", "rows"|"columns" } }
    仅三类信息：基本盘面信息 / 时间信息 / K 线信息(OHLC + BarCount)。

作用:
    1. 校验结构、BarCount 一致性、时间序、OHLC 逻辑、时间格式统一性；
    2. 计算确定性盘面事实：缺口（价格/实体）及是否回补、波段高低点、EMA20、ATR14、区间统计；
    3. 输出 Markdown 摘要（默认）或机器可读 JSON（--json）。

设计原则: 只依赖标准库；bars 为唯一事实来源；不静默填充缺失数据。
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from datetime import datetime, timezone
from typing import Any


def die(msg: str, code: int = 2) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(code)


# ---------------------------------------------------------------- 时间


def to_ms(value: Any, fmt: str, where: str) -> int:
    """把时间值统一为 epoch 毫秒（UTC）。"""
    if isinstance(value, bool) or value is None:
        die(f"{where} 时间值非法: {value!r}")
    if fmt == "epoch_ms":
        if not isinstance(value, int):
            die(f"{where} 在 epoch_ms 格式下必须为整数毫秒时间戳，实际: {value!r}")
        return value
    if not isinstance(value, str):
        die(f"{where} 在 rfc3339 格式下必须为字符串，实际: {value!r}")
    s = value.strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s)
    except ValueError as e:
        die(f"{where} 时间解析失败: {e}")
    if dt.tzinfo is None:
        die(f"{where} 时间戳缺少时区偏移: {value}")
    return int(dt.timestamp() * 1000)


def ms_to_str(ms: int) -> str:
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ---------------------------------------------------------------- 取数


def num(x: Any, where: str) -> float:
    if isinstance(x, bool) or x is None:
        die(f"{where} 价格非法: {x!r}")
    if isinstance(x, (int, float)):
        f = float(x)
        if math.isnan(f) or math.isinf(f):
            die(f"{where} 价格为 NaN/Inf")
        return f
    if isinstance(x, str):
        try:
            return float(x)
        except ValueError:
            die(f"{where} 价格字符串非法: {x!r}")
    die(f"{where} 价格类型非法: {type(x).__name__}")


# ---------------------------------------------------------------- 归一化


def normalize(payload: dict) -> tuple[dict, dict, dict, list[dict], list[str]]:
    """返回 (meta, time, bars_meta, bars, warnings)。"""
    warns: list[str] = []

    if payload.get("schema") != "zpa.market.v1":
        warns.append(f"schema 应为 'zpa.market.v1'，实际为 {payload.get('schema')!r}")

    extra = set(payload) - {"schema", "meta", "time", "bars"}
    if extra:
        warns.append(f"存在格式外的顶层字段（应移除）: {sorted(extra)}")

    meta = payload.get("meta")
    tm = payload.get("time")
    bars_obj = payload.get("bars")
    if not isinstance(meta, dict):
        die("meta 缺失或非对象")
    if not isinstance(tm, dict):
        die("time 缺失或非对象")
    if not isinstance(bars_obj, dict):
        die("bars 缺失或非对象（应为 {count, layout, rows|columns}）")

    for k in ("symbol", "interval", "price"):
        if k not in meta:
            die(f"meta 缺少必填字段 {k}")
    for k in ("timezone", "format", "start", "end"):
        if k not in tm:
            die(f"time 缺少必填字段 {k}")

    fmt = tm.get("format")
    if fmt not in ("rfc3339", "epoch_ms"):
        die(f"time.format 非法: {fmt!r}（应为 rfc3339 | epoch_ms）")

    layout = bars_obj.get("layout", "rows")
    if layout not in ("rows", "columns"):
        die(f"bars.layout 非法: {layout!r}")

    # ---- 展开 bars ----
    bars: list[dict] = []
    if layout == "rows":
        rows = bars_obj.get("rows")
        if not isinstance(rows, list) or not rows:
            die("bars.rows 缺失或为空数组")
        seq = rows
    else:
        cols = bars_obj.get("columns")
        if not isinstance(cols, dict):
            die("bars.columns 缺失或非对象")
        for k in ("t", "o", "h", "l", "c"):
            if not isinstance(cols.get(k), list) or not cols[k]:
                die(f"bars.columns.{k} 缺失或为空数组")
        n = len(cols["t"])
        for k in ("o", "h", "l", "c", "closed"):
            if k in cols and isinstance(cols[k], list) and len(cols[k]) != n:
                warns.append(f"bars.columns 列长不一致: t={n}, {k}={len(cols[k])}")
        seq = []
        for i in range(n):
            row = {k: cols[k][i] for k in ("t", "o", "h", "l", "c")
                   if isinstance(cols.get(k), list) and i < len(cols[k])}
            if isinstance(cols.get("closed"), list) and i < len(cols["closed"]):
                row["closed"] = cols["closed"][i]
            seq.append(row)

    # ---- BarCount 一致性 ----
    count = bars_obj.get("count")
    if not isinstance(count, int) or isinstance(count, bool):
        die("bars.count (BarCount) 缺失或非整数")
    if count != len(seq):
        die(f"BarCount 不一致：bars.count={count}，实际 K 线根数={len(seq)}")

    # ---- 逐根解析 ----
    for i, r in enumerate(seq):
        where = f"bars[{i}]"
        if not isinstance(r, dict):
            die(f"{where} 非对象")
        for k in ("t", "o", "h", "l", "c"):
            if k not in r:
                die(f"{where} 缺少 {k}")
        bad = set(r) - {"t", "o", "h", "l", "c", "closed"}
        if bad:
            warns.append(f"{where} 含格式外字段（应移除）: {sorted(bad)}")
        t_ms = to_ms(r["t"], fmt, where)
        o, h, l, c = (num(r[k], where) for k in ("o", "h", "l", "c"))
        if h < max(o, c) - 1e-9 or l > min(o, c) + 1e-9 or h < l:
            warns.append(f"{where} OHLC 矛盾 o={o} h={h} l={l} c={c}")
        bars.append({
            "t": ms_to_str(t_ms), "ms": t_ms,
            "o": o, "h": h, "l": l, "c": c, "closed": bool(r.get("closed", True)),
        })

    # ---- 时间序 ----
    for i in range(1, len(bars)):
        if bars[i]["ms"] < bars[i - 1]["ms"]:
            warns.append(f"NON_MONOTONIC_TIME: {bars[i]['t']}")
        elif bars[i]["ms"] == bars[i - 1]["ms"]:
            warns.append(f"DUPLICATE_TS: {bars[i]['t']}")

    # ---- time.start / end 与 bars 端点核对 ----
    s_ms = to_ms(tm["start"], fmt, "time.start")
    e_ms = to_ms(tm["end"], fmt, "time.end")
    if s_ms != bars[0]["ms"]:
        warns.append(f"time.start({ms_to_str(s_ms)}) 与首根 K 线({bars[0]['t']}) 不一致")
    if e_ms != bars[-1]["ms"]:
        warns.append(f"time.end({ms_to_str(e_ms)}) 与末根 K 线({bars[-1]['t']}) 不一致")

    if not bars[-1]["closed"]:
        warns.append(f"PARTIAL_LAST_BAR: 最后一根 K 线未收盘（{bars[-1]['t']}）")

    # ---- 数据缺口粗检 ----
    deltas = sorted(bars[i]["ms"] - bars[i - 1]["ms"] for i in range(1, len(bars)))
    if deltas:
        median = deltas[len(deltas) // 2]
        for i in range(1, len(bars)):
            dv = bars[i]["ms"] - bars[i - 1]["ms"]
            if median > 0 and dv > median * 2.5:
                warns.append(f"MISSING_BARS: {bars[i]['t']} 前跳跃 {int(dv / 1000)}s（中位 {int(median / 1000)}s）")

    return meta, tm, {"layout": layout, "count": count}, bars, warns


# ---------------------------------------------------------------- 计算


def ema(values: list[float], period: int) -> list[float | None]:
    out: list[float | None] = [None] * len(values)
    if len(values) < period:
        return out
    k = 2.0 / (period + 1)
    seed = sum(values[:period]) / period
    out[period - 1] = seed
    prev = seed
    for i in range(period, len(values)):
        prev = values[i] * k + prev * (1 - k)
        out[i] = prev
    return out


def atr(bars: list[dict], period: int = 14) -> list[float | None]:
    out: list[float | None] = [None] * len(bars)
    if len(bars) < period + 1:
        return out
    trs = [
        max(bars[i]["h"] - bars[i]["l"],
            abs(bars[i]["h"] - bars[i - 1]["c"]),
            abs(bars[i]["l"] - bars[i - 1]["c"]))
        for i in range(1, len(bars))
    ]
    prev = sum(trs[:period]) / period
    out[period] = prev
    for i in range(period + 1, len(bars)):
        prev = (prev * (period - 1) + trs[i - 1]) / period
        out[i] = prev
    return out


def swing_points(bars: list[dict], k: int = 2) -> list[dict]:
    piv: list[dict] = []
    for i in range(k, len(bars) - k):
        hi, lo = bars[i]["h"], bars[i]["l"]
        if all(hi > bars[i - j]["h"] for j in range(1, k + 1)) and all(hi > bars[i + j]["h"] for j in range(1, k + 1)):
            piv.append({"i": i, "t": bars[i]["t"], "price": hi, "raw": "H"})
        if all(lo < bars[i - j]["l"] for j in range(1, k + 1)) and all(lo < bars[i + j]["l"] for j in range(1, k + 1)):
            piv.append({"i": i, "t": bars[i]["t"], "price": lo, "raw": "L"})
    piv.sort(key=lambda p: p["i"])
    last_h = last_l = None
    for p in piv:
        if p["raw"] == "H":
            p["kind"] = "HH" if (last_h is None or p["price"] > last_h) else "LH"
            last_h = p["price"]
        else:
            p["kind"] = "HL" if (last_l is None or p["price"] > last_l) else "LL"
            last_l = p["price"]
    return piv


def detect_gaps(bars: list[dict], tick: float) -> list[dict]:
    gaps: list[dict] = []
    eps = 1e-9
    for i in range(1, len(bars)):
        p, cur = bars[i - 1], bars[i]
        checks = [
            ("price", "up", p["h"], cur["l"], p["h"] < cur["l"] - eps),
            ("price", "down", cur["h"], p["l"], cur["h"] < p["l"] - eps),
            ("body", "up", max(p["o"], p["c"]), min(cur["o"], cur["c"]), max(p["o"], p["c"]) < min(cur["o"], cur["c"]) - eps),
            ("body", "down", max(cur["o"], cur["c"]), min(p["o"], p["c"]), max(cur["o"], cur["c"]) < min(p["o"], p["c"]) - eps),
        ]
        for kind, direction, lower, upper, hit in checks:
            if not hit:
                continue
            if tick and (upper - lower) < tick - eps:
                continue
            filled, filled_at = False, None
            for j in range(i + 1, len(bars)):
                if direction == "up" and bars[j]["l"] <= lower + eps:
                    filled, filled_at = True, bars[j]["t"]
                    break
                if direction == "down" and bars[j]["h"] >= upper - eps:
                    filled, filled_at = True, bars[j]["t"]
                    break
            gaps.append({
                "t": cur["t"], "direction": direction, "kind": kind,
                "lower": round(lower, 10), "upper": round(upper, 10),
                "size": round(upper - lower, 10),
                "filled": filled, "filledAt": filled_at,
            })
    return gaps


# ---------------------------------------------------------------- 报告


def build_digest(payload: dict) -> dict:
    meta, tm, bmeta, bars, warns = normalize(payload)
    price_meta = meta.get("price") or {}
    if not price_meta.get("tickSize"):
        warns.append("meta.price.tickSize 缺失，tick 对齐无法校验")
    tick = num(price_meta["tickSize"], "meta.price.tickSize") if price_meta.get("tickSize") else 0.0

    gaps = detect_gaps(bars, tick)
    swings = swing_points(bars, k=2)
    ema20 = ema([b["c"] for b in bars], 20)
    atr14 = atr(bars, 14)

    hi, lo = max(b["h"] for b in bars), min(b["l"] for b in bars)
    last = bars[-1]

    return {
        "meta": {k: meta.get(k) for k in
                 ("symbol", "name", "assetClass", "venue", "currency", "interval", "source", "pointValue")},
        "time": {"timezone": tm.get("timezone"), "format": tm.get("format"),
                 "start": ms_to_str(bars[0]["ms"]), "end": ms_to_str(bars[-1]["ms"]),
                 "generatedAt": tm.get("generatedAt")},
        "tick": tick,
        "bar_count": len(bars),
        "count_declared": bmeta["count"],
        "layout": bmeta["layout"],
        "last_closed": bars[-1]["closed"],
        "warnings": warns,
        "bars": bars,
        "gaps": gaps,
        "swings": swings,
        "ema20_last": ema20[-1] if ema20 else None,
        "atr14_last": atr14[-1] if atr14 else None,
        "range": {"high": hi, "low": lo, "width": round(hi - lo, 10),
                  "last_close": last["c"],
                  "pos_in_range": round((last["c"] - lo) / (hi - lo), 4) if hi > lo else None},
    }


def fmt(v: Any) -> str:
    if v is None:
        return "—"
    if isinstance(v, float):
        return f"{v:g}"
    return str(v)


def render_markdown(d: dict, last_n: int) -> str:
    m, tm = d["meta"], d["time"]
    L: list[str] = []
    L.append(f"# 盘面数据摘要 · {fmt(m.get('symbol'))} {fmt(m.get('interval'))}")
    L.append("")
    L.append(f"- 会话时区: {fmt(tm.get('timezone'))}  时间格式: {fmt(tm.get('format'))}")
    L.append(f"- 时间范围: {tm.get('start')} → {tm.get('end')}")
    L.append(f"- BarCount: {d['count_declared']}（校验通过）  布局: {d['layout']}  末根已收盘: {d['last_closed']}")
    if d.get("tick"):
        L.append(f"- 最小变动价位 tickSize: {d['tick']}")

    L.append("")
    L.append("## 数据质量")
    if d["warnings"]:
        for w in d["warnings"]:
            L.append(f"- {w}")
    else:
        L.append("- 校验通过，无告警")

    L.append("")
    n = min(last_n, len(d["bars"]))
    L.append(f"## 最近 {n} 根 K 线")
    L.append("| t | O | H | L | C | 标记 |")
    L.append("|---|---|---|---|---|---|")
    for b in d["bars"][-n:]:
        rel = "阳" if b["c"] > b["o"] else ("阴" if b["c"] < b["o"] else "平")
        tag = "" if b["closed"] else " 未收盘"
        L.append(f"| {b['t'][5:16]} | {fmt(b['o'])} | {fmt(b['h'])} | {fmt(b['l'])} | {fmt(b['c'])} | {rel}{tag} |")

    L.append("")
    L.append("## 缺口（价格 / 实体）")
    if not d["gaps"]:
        L.append("- 未检出缺口（震荡区间的典型特征）")
    else:
        L.append("| 时间 | 方向 | 类型 | 区间 | 大小 | 状态 |")
        L.append("|---|---|---|---|---|---|")
        for g in d["gaps"]:
            L.append(
                f"| {g['t'][5:16]} | {'向上' if g['direction'] == 'up' else '向下'} | "
                f"{'价格' if g['kind'] == 'price' else '实体'} | "
                f"{fmt(g['lower'])} ~ {fmt(g['upper'])} | {fmt(g['size'])} | "
                f"{'已回补@' + g['filledAt'][5:16] if g['filled'] else '**仍敞开**'} |"
            )
        open_gaps = [g for g in d["gaps"] if not g["filled"]]
        L.append("")
        L.append(f"- 未回补缺口数: **{len(open_gaps)}**" + ("" if open_gaps else "（全部已回补 → 弱趋势/震荡特征）"))

    L.append("")
    L.append("## 波段高低点（分形 k=2）")
    if not d["swings"]:
        L.append("- 未识别到明确波段点")
    else:
        L.append("- 最近序列: " + " → ".join(
            f"{p['kind']}@{fmt(p['price'])}({p['t'][5:16]})" for p in d["swings"][-8:]))

    L.append("")
    L.append("## 指标（由 OHLC 现算）")
    ema_pos = "—"
    if d["ema20_last"] is not None:
        ema_pos = "上方" if d["range"]["last_close"] > d["ema20_last"] else "下方"
    L.append(f"- EMA20: {fmt(d['ema20_last'])}  ｜ 收盘相对 EMA20: {ema_pos}")
    L.append(f"- ATR14: {fmt(d['atr14_last'])}")

    L.append("")
    L.append("## 区间统计")
    r = d["range"]
    L.append(f"- 窗口最高 {fmt(r['high'])} / 最低 {fmt(r['low'])} / 宽度 {fmt(r['width'])}")
    L.append(f"- 最新收盘 {fmt(r['last_close'])}，位于区间 {fmt(r['pos_in_range'])} 处（0=底 1=顶）")

    L.append("")
    L.append("> 以上为脚本计算的确定性事实，供 Zpa SKILL 第 1–5 步推理使用；结论仍需人工判断。")
    return "\n".join(L)


def main() -> None:
    ap = argparse.ArgumentParser(description="zpa.market.v1 校验 + 摘要")
    ap.add_argument("file", help="JSON 文件路径，或 - 表示 stdin")
    ap.add_argument("--last", type=int, default=40, help="打印最近 N 根 K 线（默认 40）")
    ap.add_argument("--swing-k", type=int, default=2, help="分形波段左右窗口（默认 2）")
    ap.add_argument("--json", action="store_true", help="输出机器可读 JSON 摘要")
    args = ap.parse_args()

    try:
        if args.file == "-":
            payload = json.load(sys.stdin)
        else:
            with open(args.file, "r", encoding="utf-8") as fh:
                payload = json.load(fh)
    except FileNotFoundError:
        die(f"文件不存在: {args.file}")
    except json.JSONDecodeError as e:
        die(f"JSON 解析失败: {e}")

    d = build_digest(payload)

    if args.json:
        out = {k: v for k, v in d.items() if k != "bars"}
        out["bars"] = d["bars"][-args.last:]
        print(json.dumps(out, ensure_ascii=False, indent=2, default=str))
    else:
        print(render_markdown(d, args.last))


if __name__ == "__main__":
    main()
